//
//  LhwPaoMaDengLable.h
//  LhwPaomadengLable
//
//  Created by 鲁宏伟 on 16/12/8.
//  Copyright © 2016年 鲁宏伟. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LhwPaoMaDengLable : UIView

/**
 内容文字
 */
@property (nonatomic, strong) NSString *text;

/**
 字体 默认15
 */
@property (nonatomic, strong) UIFont *font;

/**
 字体颜色
 */
@property (nonatomic, strong) UIColor *textColor;

/**
 富文本
 */
@property (nonatomic, strong) NSAttributedString *attributedText;

/**
 速度
 */
@property (nonatomic, assign) NSInteger speed;

/**
 循环滚动次数(为0时无限滚动)
 */
@property (nonatomic, assign) NSUInteger repeatCount;

/**
 第二遍开始与第一遍结束之间的空格大小
 */
@property (nonatomic, assign) CGFloat leastInnerGap;

/**
 是否结束停留
 */
@property(nonatomic,assign)BOOL IsEndStay;

/**
 重载
 */
- (void)reloadView;

@end
