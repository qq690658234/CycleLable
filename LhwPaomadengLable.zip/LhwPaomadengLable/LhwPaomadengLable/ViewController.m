//
//  ViewController.m
//  LhwPaomadengLable
//
//  Created by 鲁宏伟 on 16/12/8.
//  Copyright © 2016年 鲁宏伟. All rights reserved.
//

#import "ViewController.h"
#import "LhwPaoMaDengLable.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton* but=[[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    [but addTarget:self action:@selector(butupinsdie) forControlEvents:UIControlEventTouchUpInside];
    [but setBackgroundColor:[UIColor redColor]];
    [self.view addSubview:but];
}
-(void)butupinsdie{
    LhwPaoMaDengLable* paomadeng =[[LhwPaoMaDengLable alloc]initWithFrame:CGRectMake(0, 300, self.view.frame.size.width, 50)];
    [self.view addSubview:paomadeng];
    paomadeng.backgroundColor=[UIColor orangeColor];
    paomadeng.text=@"wo231123123123123121233qwenqweqweqweqweqeewqeqweqweqweni";
    NSAttributedString *as = [[NSAttributedString alloc] initWithString:@"啊哈哈哈wo231123123123123121233niahah" attributes:@{NSStrikethroughStyleAttributeName:[NSNumber numberWithFloat:1.0], NSStrikethroughColorAttributeName:[UIColor purpleColor],NSFontAttributeName:[UIFont  systemFontOfSize:10]}];
//    paomadeng.attributedText=as;
    paomadeng.font=[UIFont  systemFontOfSize:30];
    paomadeng.speed=100;
    paomadeng.leastInnerGap=100;
    paomadeng.textColor=[UIColor redColor];
    paomadeng.IsEndStay=YES;
}

@end
